package cp213;

/**
 * @author Mikhail Karmali 201495920
 * @version 2021-09-11
 */
public class LeapYear {

    /**
     * Determines whether or not a year is a leap year.
     *
     * A leap year is defined as:
     *
     * "Every year that is exactly divisible by four is a leap year, except for
     * years that are exactly divisible by 100, but these centurial years are leap
     * years if they are exactly divisible by 400. For example, the years 1700,
     * 1800, and 1900 are not leap years, but the years 1600 and 2000 are." (United
     * States Naval Observatory)
     *
     * Thus 1996, 2000, and 2004 are leap years, but 1899, 1900, and 1901 are not
     * leap years."
     *
     * @param year The year to test (int greater than 0)
     * @return true if year is a leap year, false otherwise.
     */
    public static boolean isLeapYear(final int year) {
    boolean check_year = false;
    double time;
    
    if (year%4 == 0) {
    	check_year = true;
    }
    
    if (year%100 == 0) {
    	time = year/100;
    	if (time%4 == 0) {
    		check_year = true;
    	}
    	else {
    		check_year = false;
    	}
    		
    }

	return check_year;
    }

}
