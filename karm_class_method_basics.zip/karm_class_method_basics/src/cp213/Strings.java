package cp213;

/**
 * @author Mikhail Karmali 201495920
 * @version 2021-09-11
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU";

    /**
     * Determines if string is a "palindrome": a word, verse, or sentence (such as "Able
     * was I ere I saw Elba") that reads the same backward or forward. Ignores case,
     * spaces, digits, and punctuation in the string parameter s.
     *
     * @param string a string
     * @return true if string is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String string) {
	String flipped = "";
	Boolean result = false;
	
	final String ACCEPT = "abcdefghijklmnoprstuvwxyz";
	
	for (int x = string.length()-1; x>=0; x--) {
		flipped = flipped + string.charAt(x);
		
	}
	
	String forward = string;
	
	flipped = flipped.toLowerCase();
	forward = forward.toLowerCase();
	
	
	for (int x = 0; x < flipped.length(); x++) {
		if(!ACCEPT.contains(String.valueOf(flipped.charAt(x)))) {
			flipped = flipped.replace(flipped.charAt(x), ' ');
		}
	}
	flipped = flipped.replaceAll("\\s+", "");
	
	for (int x = 0; x < forward.length(); x++) {
		if(!ACCEPT.contains(String.valueOf(forward.charAt(x)))) {
			forward = forward.replace(forward.charAt(x), ' ');
		}
	}
	
	
	forward = forward.replaceAll("\\s+", "");
	
	if(forward.equals(flipped)) {
		result = true;
	}

	return result;
    }

    /**
     * Determines if name is a valid Java variable name. Variables names must start
     * with a letter or an underscore, but cannot be an underscore alone. The rest
     * of the variable name may consist of letters, numbers and underscores.
     *
     * @param name a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {

	boolean result = true;
	char begin = name.charAt(0);
	
	if(name.isEmpty()) {
		result = false;
	}
	
	if(name.charAt(0) == '_') {
		result = true;
		if(name.charAt(1) == ' ') {
			result = false;
		}
	}
	
	if(Character.isDigit(begin) == true) {
		result = false;
	}

	return result;
    }

    /**
     * Converts a word to Pig Latin. The conversion is:
     * <ul>
     * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
     * <li>if the word begins with consonants, move the leading consonants to the
     * end of the word and add "ay" to the end of that. "y" is treated as a
     * consonant if it is the first character in the word, and as a vowel for
     * anywhere else in the word.</li>
     * </ul>
     * Preserve the case of the word - i.e. if the first character of word is
     * upper-case, then the new first character should also be upper case.
     *
     * @param word The string to convert to Pig Latin
     * @return the Pig Latin version of word
     */
    public static String pigLatin(String word) {
    String result = "";
        
        if (VOWELS.indexOf(word.charAt(0)) != -1) {
            result = word + "way";
            }
        
        else {
            String result_t = "";
            result_t += word.charAt(1);
            
            if (Character.isUpperCase(word.charAt(0))){
            	result += result_t.toUpperCase();
                }
            
            else
            	result += result_t.toLowerCase();
            
            for(int a1 = 2; a1 < word.length(); a1++){
            	result += word.charAt(a1);
                }
            result += (word.charAt(0) + "ay").toLowerCase();
            }
        
            return result;
            }
}
