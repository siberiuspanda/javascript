package cp213;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.print.PrinterJob;

import javax.swing.*;

/**
 * The GUI for the Order class.
 *
 * @author Mikhail Karmali
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2021-11-01
 */
@SuppressWarnings("serial")
public class OrderPanel extends JPanel {

    /**
     * Implements an ActionListener for the 'Print' button. Prints the current
     * contents of the Order to a system printer or PDF.
     */
    private class PrintListener implements ActionListener {

	@Override
	public void actionPerformed(final ActionEvent e) {
	    final PrinterJob printJob = PrinterJob.getPrinterJob();
	    printJob.setPrintable(order);

	    if (printJob.printDialog()) {
		try {
		    printJob.print();
		} catch (final Exception printException) {
		    System.err.println(printException);
		}
	    }
	}
    }

    /**
     * Implements a FocusListener on a JTextField. Accepts only positive integers,
     * all other values are reset to 0. Adds a new MenuItem to the Order with the
     * new quantity, updates an existing MenuItem in the Order with the new
     * quantity, or removes the MenuItem from the Order if the resulting quantity is
     * 0.
     */
    private class QuantityListener implements FocusListener {

	// your code here

	@Override
	public void focusGained(final FocusEvent evt) {

	}

	@Override
	public void focusLost(final FocusEvent evt) {
		JTextField src = (JTextField) evt.getSource();
		try {
			order.update(menu.getItem(Integer.parseInt(src.getName())), Integer.parseInt(src.getText()));
			subtotalLabel.setText(String.format("$%.2f", order.getSubTotal()));
			taxes.setText(String.format("$%.2f", order.getTaxes()));
			totalLabel.setText(String.format("$%.2f", order.getTotal()));
			if (Integer.parseInt(src.getText())<0){
				src.setText("0");
			}
		} catch (Exception e){
			System.out.println(e);
			order.update(menu.getItem(Integer.parseInt(src.getName())), 0);
			src.setText("0");
			}
		}
	}

    // Attributes
    private Menu menu = null;
    private final Order order = new Order();
    private final JButton print_button = new JButton("Print");
    private final JLabel subtotalLabel = new JLabel("$0.00");
    private final JLabel taxes = new JLabel("$0.00");
    private final JLabel totalLabel = new JLabel("$0.00");

    /**
     * Displays the menu in a GUI.
     *
     * @param menu The menu to display.
     */
    public OrderPanel(final Menu menu) {
	this.menu = menu;
	this.layoutView();
    }

    /**
     * Uses the GridLayout to place the labels and buttons.
     */
    private void layoutView() {
	this.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
	// Number of rows of GridLayout must be updated to accommodate all MenuItems,
	// totals, and Print button
	this.setLayout(new GridLayout(0, 3));
	this.add(new JLabel("Item"));
	this.add(new JLabel("Price"));
	this.add(new JLabel("Quantity"));

	JLabel [] name= new JLabel[menu.size()];
	JLabel [] price= new JLabel[menu.size()];
	JTextField [] textFields = new JTextField[menu.size()];
	for( int i = 0 ; i<menu.size() ; i++ ){
		name[i]=new JLabel(menu.getItem(i).getName());
		this.add(name[i]);
		name[i].setHorizontalAlignment(SwingConstants.LEFT);
		price[i]=new JLabel("$" + menu.getItem(i).getPrice().doubleValue());
		this.add(price[i]);
		price[i].setHorizontalAlignment(SwingConstants.RIGHT);
		textFields[i]= new JTextField("0");
		textFields[i].setName(String.valueOf(i));
		this.add(textFields[i]);
		textFields[i].setHorizontalAlignment(SwingConstants.RIGHT);
		// Register listeners here
		textFields[i].addFocusListener(new QuantityListener());
	}
	this.add(new JLabel("Subtotal:"));
	this.add(Box.createGlue());
	this.add(subtotalLabel);
	subtotalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
	this.add(new JLabel("Tax:"));
	this.add(Box.createGlue());
	this.add(taxes);
	taxes.setHorizontalAlignment(SwingConstants.RIGHT);
	this.add(new JLabel("Total:"));
	this.add(Box.createGlue());
	this.add(totalLabel);
	totalLabel.setHorizontalAlignment(SwingConstants.RIGHT);
	this.add(Box.createGlue());
	this.print_button.addActionListener(new PrintListener());
	this.add(this.print_button);
	print_button.setHorizontalAlignment(SwingConstants.CENTER);
	return;
}
}