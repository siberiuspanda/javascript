package cp213;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores a HashMap of MenuItem objects and the quantity of each MenuItem
 * ordered. Each MenuItem may appear only once in the HashMap.
 *
 * @author Mikhail Karmali
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2021-11-01
 */
public class Order implements Printable {

    /**
     * The current tax rate on menu items.
     */
    public static final BigDecimal TAX_RATE = new BigDecimal(0.13);
    private Map<MenuItem, Integer> items = new HashMap<MenuItem, Integer>();

    /**
     * Update the quantity of a particular MenuItem in an order.
     *
     * @param item     The MenuItem to purchase - the HashMap key.
     * @param quantity The number of the MenuItem to purchase - the HashMap value.
     */
    public void add(MenuItem item, int quantity) {

		if (quantity > 0) {
			if (this.items.containsKey(item))
				update(item, quantity + this.items.get(item));
			else
				this.items.put(item, quantity);
		}

	}

    /**
     * Calculates the total value of all MenuItems and their quantities in the
     * HashMap.
     *
     * @return the total price for the MenuItems ordered.
     */
    public BigDecimal getSubTotal() {

		BigDecimal final_total = new BigDecimal(0.00);
		for (Map.Entry<MenuItem, Integer> order : items.entrySet())
			final_total = BigDecimal
					.valueOf(final_total.doubleValue() + ((order.getValue()) * (order.getKey().getPrice().doubleValue())));

		final_total.setScale(2, RoundingMode.HALF_EVEN);
		return final_total;
    }

    /**
     * Calculates and returns the total taxes to apply to the subtotal of all
     * MenuItems in the order. Tax rate is TAX_RATE.
     *
     * @return total taxes on all MenuItems
     */
    public BigDecimal getTaxes() {


	return BigDecimal.valueOf(TAX_RATE.doubleValue() * getSubTotal().doubleValue());
    }

    /**
     * Calculates and returns the total price of all MenuItems order, including tax.
     *
     * @return total price
     */
    public BigDecimal getTotal() {

	// your code here

	return BigDecimal.valueOf(getSubTotal().doubleValue() + getTaxes().doubleValue());
    }

    /**
     * Returns a String version of a receipt for all the MenuItems in the order.
     */
    @Override
    public String toString() {
		StringBuilder final_recipt = new StringBuilder();
		for (Map.Entry<MenuItem, Integer> order : items.entrySet()) {
			String format1 = "";
			String format2 = "";
			BigDecimal item_cost;
			item_cost = BigDecimal.valueOf(order.getValue().doubleValue() * order.getKey().getPrice().doubleValue());
			if (order.getKey().getPrice().intValue() < 10) {
				format1 = " ";
			}
			if (item_cost.intValue() < 10) {
				format2 = "  ";
			} else if (item_cost.intValue() < 100) {
				format2 = " ";
			}

			final_recipt.append(String.format("%-15s%-3d@\t$" + format1 + "%.2f\t=\t$" + format2 + "%.2f",
					order.getKey().getName(), order.getValue(), order.getKey().getPrice(), item_cost)).append("\n");
		}
		String format3 = "";
		String format4 = "";
		String format5 = "";
		if (getSubTotal().intValue() < 10) {
			format3 = "  ";
		} else if (getSubTotal().intValue() < 100) {
			format3 = " ";
		}
		if (getTaxes().intValue() < 10) {
			format4 = "  ";
		} else if (getTaxes().intValue() < 100) {
			format4 = " ";
		}
		if (getTotal().intValue() < 10) {
			format5 = "  ";
		} else if (getTotal().intValue() < 100) {
			format5 = " ";
		}
		final_recipt.append("\n");
		
		final_recipt.append(String.format("%-32s\t$" + format3 + "%.2f", "Subtotal:", getSubTotal())).append("\n");
		
		final_recipt.append(String.format("%-32s\t$" + format4 + "%.2f", "Taxes:", getTaxes())).append("\n");
		
		final_recipt.append(String.format("%-32s\t$" + format5 + "%.2f", "Total", getTotal())).append("\n");

		return String.valueOf(final_recipt);
    }

    /**
     * Replaces the quantity of a particular MenuItem in an Order with a new
     * quantity. If the MenuItem is not in the order, it is added. If quantity is 0
     * or negative, the MenuItem is removed from the Order.
     *
     * @param item The MenuItem to update
     * @param quantity The quantity to apply to item
     */
    public void update(MenuItem item, int quantity) {

		if (quantity <= 0 && this.items.containsKey(item))
			this.items.remove(item);
		else if (!this.items.containsKey(item))
			add(item, quantity);
		else
			this.items.replace(item, quantity);

	}

    /*
     * Implements the Printable interface print method. Prints lines to a Graphics2D
     * object using the drawString method. Prints the current contents of the Order.
     */
    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
	int result = PAGE_EXISTS;
	int x = 200;

	if (pageIndex == 0) {
	    Graphics2D g2d = (Graphics2D) graphics;
	    g2d.setFont(new Font("MONOSPACED", Font.PLAIN, 12));
	    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
	    int height = g2d.getFontMetrics().getHeight();
        for (String line : this.toString().split("\n")) {
            g2d.drawString(line, 100, x += height);
        }

    } else {
        result = NO_SUCH_PAGE;
    }
    return result;
    }
}