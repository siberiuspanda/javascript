package cp213;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author Mikhail Karmali
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2021-11-01
 */
public class Cashier {

    private Menu menu = null;

    /**
     * Constructor.
     *
     * @param menu A Menu.
     */
    public Cashier(Menu menu) {
	this.menu = menu;
    }

    /**
     * Asks for commands and quantities. Prints a receipt when all orders have been
     * placed.
     *
     * @return the completed Order.
     */
    public Order takeOrder() {

    	System.out.println("Welcome to the WLU Foodorama!");
    	System.out.println();
    	this.print_menu();
    	
    	Order current_order = new Order();
    	Scanner scan = new Scanner(System.in);
    	String receipt = "";
    	boolean isvalid = true; 
    	int multiplier;
    	int chosen_item = 0;
    	boolean valid_item = false;
 
    	while (isvalid) {

    		try {
    			System.out.print("Command: ");
    			chosen_item = scan.nextInt();
        		if (chosen_item >= 1 && chosen_item <= 7) {
        			valid_item = true;
        		}
        		else if (chosen_item == 0){
        			isvalid = false;
        			valid_item = false;
        		}
        		else {

        			this.print_menu();
        			valid_item = false;
        		}
    		}
    		catch (InputMismatchException  e){
    			System.out.println("Not a valid number");
    			this.print_menu();
    			valid_item = false;
    			scan.nextLine();
    		}
    		if (valid_item) {
    			try {
    				System.out.print("How many do you want? ");
    				multiplier = scan.nextInt();
    				current_order.add(menu.getItem(chosen_item-1), multiplier);
    				
    			}
    			catch (InputMismatchException  e) {
    				System.out.println("Not a valid number");
    				scan.nextLine();
    			}
    		}
    		
    		
    		}
    	scan.close();
    	System.out.println("Receipt");
		receipt = current_order.toString();
    	System.out.println(receipt);
	return current_order;
    }
    private void print_menu() {
    	try {
    	    Menu menu = new Menu("menu.txt");
    	    System.out.println("Menu:");
    	    System.out.print(menu.toString());
    	    System.out.println("Press 0 when done.");
        	System.out.println("Press any other key to see the menu again.");
        	System.out.println();
    	} catch (FileNotFoundException e) {
    	    System.out.println("Cannot open menu file");
    	}
     }
}