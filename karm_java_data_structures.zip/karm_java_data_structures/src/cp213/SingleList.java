package cp213;

import java.util.Objects;

/**
 * A single linked list structure of <code>Node T</code> objects. These data
 * objects must be Comparable - i.e. they must provide the compareTo method.
 * Only the <code>T</code> value contained in the priority queue is visible
 * through the standard priority queue methods. Extends the
 * <code>SingleLink</code> class.
 *
 * @author David Brown
 * @version 2021-09-24
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

    private static final int SingleNode = 0;

	/**
     * Searches for the first occurrence of key in this SingleList. Private helper
     * methods - used only by other ADT methods.
     *
     * @param key The value to look for.
     * @return A pointer to the node previous to the node containing key.
     */

	private SingleNode<T> linearSearch(final T key) {
    	
		
    	SingleNode<T> cur = this.front;
    	Boolean valid = false;
    	
    	
    	while (Objects.isNull(cur) == false && valid == false) {
    		if (cur.getData().compareTo(key) == 0) {
    			valid = true;
    		}
    		else {
    			cur = cur.getNext();
    			
    		}
    	}

	return cur;
    }

    /**
     * Appends data to the end of this SingleList.
     *
     * @param data The value to append.
     */
    public void append(final T data) {

    	
    	SingleNode<T> cr_node = new SingleNode<T>(data,null);
    	
    	
    	if (this.length == 0) {
    		this.front = cr_node;
    	}
    	
    	else {
    		this.rear.setNext(cr_node);
    	}
    	
    	this.rear = cr_node;
    	this.length += 1;
    	

	return;
    }

    /**
     * Removes duplicates from this SingleList. The list contains one and only one
     * of each value formerly present in this SingleList. The first occurrence of
     * each value is preserved.
     */
    public void clean() { 

    	
    	SingleNode<T> node1 = null, node2 = null;
    	node1 = this.front;
    	
    	
    	while (node1 != null && node1.getNext() != null) {
    		node2 = node1;
    		
    		while (node2.getNext() != null) {
    			
    			if (node1.getData().compareTo(node2.getNext().getData()) == 0) {
    				node2.setNext(node2.getNext().getNext());
    			}
    			else {
    				node2 = node2.getNext();
    			}
    		}
    		node1 = node1.getNext();
    	}

	return;
    }

    /**
     * Combines contents of two lists into a third. Values are alternated from the
     * origin lists into this SingleList. The origin lists are empty when finished.
     * NOTE: data must not be moved, only nodes.
     *
     * @param left  The first list to combine with this SingleList.
     * @param right The second list to combine with this SingleList.
     */
    public void combine(final SingleList<T> left, final SingleList<T> right) {

    	boolean valid = true;
    	while (left.length != 0 || right.length != 0) {
    		if (valid) {
    			if (left.length == 0) {
    				this.moveFrontToRear(right);
    			}else {
    				this.moveFrontToRear(left);
    			}
    		}else {
    			if (right.length == 0) {
    				this.moveFrontToRear(left);
    			}else {
    				this.moveFrontToRear(right);
    			}
    		}
    		valid = !valid;
    	}

	return;
    }

    /**
     * Determines if this SingleList contains key.
     *
     * @param key The key value to look for.
     * @return true if key is in this SingleList, false otherwise.
     */
    public boolean contains(final T key) {
    	boolean valid = false;
    	
    	SingleNode<T> result = this.linearSearch(key);
    	if (Objects.isNull(result) == false) {
    		valid = true;
    	}
    	
	return valid;
    }

    /**
     * Finds the number of times key appears in list.
     *
     * @param key The value to look for.
     * @return The number of times key appears in this SingleList.
     */
    public int count(final T key) {

    	int count = 0;
    	SingleNode<T> current_node = this.front;
    	
    	while (Objects.isNull(current_node) == false) {
    		if (current_node.getData().compareTo(key) == 0) {
    			count += 1;
    		}
    		current_node = current_node.getNext();
    	}

	return count;
    }

    /**
     * Finds and returns the value in list that matches key.
     *
     * @param key The value to search for.
     * @return The value that matches key, null otherwise.
     */
    public T find(final T key) {
    	T value = null; 
    	SingleNode<T> result = this.linearSearch(key);
    	if (Objects.isNull(result) == false) {
    		value = result.getData();
    	}
	return value;
    }

    /**
     * Get the nth item in this SingleList.
     *
     * @param n The index of the item to return.
     * @return The nth item in this SingleList.
     * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
     */
    public T get(final int n) throws ArrayIndexOutOfBoundsException {

    	int counter = 0;
    	SingleNode<T> current = this.front;
    	while (Objects.isNull(current) == false && counter != n) {
    		current = current.getNext();
    		counter += 1;
    		}
    	T value = current.getData();

	return value;
    }

    /**
     * Determines whether two lists are identical.
     *
     * @param source The list to compare against this SingleList.
     * @return true if this SingleList contains the same values in the same order as
     *         source, false otherwise.
     */
    public boolean identical(final SingleList<T> source) {
    	boolean valid;
    	
    	if (this.length != source.length) {
    		valid = false;
    	}
    	else {
    		SingleNode<T> source_current = this.front; 
    		SingleNode<T> target_current = source.front;
    		
    		while (source_current != null && source_current.getData().compareTo(target_current.getData()) == 0) {
    			source_current = source_current.getNext();
    			target_current = target_current.getNext();
    		}
    		valid = Objects.isNull(source_current);
    	}
	
    	
    	return valid;
    }

    /**
     * Finds the first location of a value by key in this SingleList.
     *
     * @param key The value to search for.
     * @return The index of key in this SingleList, -1 otherwise.
     */
    public int index(final T key) {
    	
    	int result = -1;
    	int counter = 0;
    	SingleNode<T> current = this.front;
    	
    	
    	while (Objects.isNull(current) == false && result == -1) {
    		if (current.getData().compareTo(key) == 0) {
    			result = counter;
    		}
    		else {
    			current = current.getNext();
    			counter += 1;
    		}
    	}

	return result;
    }

    /**
     * Inserts value into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i     The index to insert the new data at.
     * @param data The new value to insert into this SingleList.
     */
    public void insert(int i, final T data) {

    	
    	if (i < 0) {
    		i = this.length + i;
    	}
    	else if (i >= this.length) {
    		this.append(data);
    	}
    	else if (i <= 0) {
    		this.prepend(data);
    	}
    	else {
    		
        	SingleNode<T> new_node = new SingleNode<T>(data,null);
        	int count = 0;
        	SingleNode<T> prev = null;
        	SingleNode<T> current = this.front;
        	
        	
        	while (count < i) {
        		prev = current;
        		current = current.getNext();
        		count += 1;
        	}
        	
        	new_node.setNext(current);
        	prev.setNext(new_node);
        	this.length += 1;
    	}
    		

	return;
    }

    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
    public void intersection(final SingleList<T> left, final SingleList<T> right) {

    	SingleNode<T> current = left.front;
    	
    	while (Objects.isNull(current) == false) {
    		T value = current.getData();
    		SingleNode<T> search = right.linearSearch(value);
    		
    		if (Objects.isNull(search) == false) {
    			SingleNode<T> search1 = this.linearSearch(value);
    			
    			if (Objects.isNull(search1)) {
    				this.append(value);
    			}
    		}
    		current = current.getNext();
    	}

	return;
    }

    /**
     * Finds the maximum value in this SingleList.
     *
     * @return The maximum value.
     */
    public T max() {
    	T current_max = null;
    	
    	if (this.length != 0) {
    		current_max = this.front.getData();
    		SingleNode<T> current = this.front;
    		
    		
    		while (Objects.isNull(current) == false) {
    			
    			if (current_max.compareTo(current.getData()) < 0) {
    				current_max = current.getData();
    			}
    			current = current.getNext();
    		
    		}
    	}

	return current_max;
    }

    /**
     * Finds the minimum value in this SingleList.
     *
     * @return The minimum value.
     */
    public T min() {

    	T current_min = null;
    	
    	if (this.length != 0) {
    		current_min = this.front.getData();
    		SingleNode<T> current = this.front;
    		
    		
    		while (Objects.isNull(current) == false) {
    			
    			if (current.getData().compareTo(current_min) < 0) {
    				current_min = current.getData();
    			}
    			current = current.getNext();
    		}
    			
    	}
    	

	return current_min;
    }

    /**
     * Inserts value into the front of this SingleList.
     *
     * @param data The value to insert into the front of this SingleList.
     */
    public void prepend(final T data) {
    	
    	
    	SingleNode<T> node = new SingleNode<T>(data,null);
    	
    	
    	this.front = node;
    	if (this.length == 0) {
    		this.rear = this.front;
    	}
    	this.length += 1;
	return;
    }

    /**
     * Finds, removes, and returns the value in this SingleList that matches key.
     *
     * @param key The value to search for.
     * @return The value matching key, null otherwise.
     */
    public T remove(final T key) {
    	T value = null;
    	
    	SingleNode<T> contains = this.linearSearch(key);
    	
    	if (contains != null) {
    		value = contains.getData();
    		if (this.index(key)>0) {
    			SingleNode<T> prev = this.front;
    			int count = 0;
    			while (count < this.index(key) - 1) {
    				prev = prev.getNext();
    				count += 1;
    			}
    			if (key.compareTo(this.rear.getData()) == 0) {
    				this.rear = prev;
    			}
    			prev.setNext(contains.getNext());
    		}
    		else {
    			this.front = this.front.getNext();
    		}
    		this.length -= 1;
    		
    	}
    		
	return value;
    }

    /**
     * Removes the value at the front of this SingleList.
     *
     * @return The value at the front of this SingleList.
     */
    public T removeFront() {
    	T value = null;
    	
    	if (this.length != 0) {
    		value = this.front.getData();
    		this.front = this.front.getNext();    	
    		this.length--;
    	}
    	
    	if (this.length == 0) {
    		this.rear = null;
    	}

	return value;
    }

    /**
     * Finds and removes all values in this SingleList that match key.
     *
     * @param key The value to search for.
     */
    public void removeMany(final T key) {
    	SingleNode<T> current = this.front;
    	SingleNode<T> prev = null;
    	
    	while (current != null && current.getData().compareTo(key) == 0) {
    		this.front = current.getNext();
    		current = this.front;
    	}
    	while (current != null) {
    		while (current != null && current.getData().compareTo(key) != 0) {
    			prev = current;
    			current = current.getNext();
    		}
    		
    		if (current == null) 
    			return;
    		prev.setNext(current.getNext());
    		current = prev.getNext();
    	}
    	

	return;
    }

    /**
     * Reverses the order of the values in this SingleList.
     */
    public void reverse() {

    	this.rear = this.front;
    	SingleNode<T> current = this.front, prev = null;
    	
    	
    	while (Objects.isNull(current) == false) {
    		SingleNode<T> temp = current.getNext();
    		current.setNext(prev);
    		prev = current;
    		current = temp;
    	}
    	this.front = prev;
	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. The first half of this
     * SingleList is moved to left, and the last half of this SingleList is moved to
     * right. If the resulting lengths are not the same, left should have one more
     * item than right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void split(final SingleList<T> left, final SingleList<T> right) {
    	int center = 0;
    	
    	if (this.length != 0) {
    		
    		if (this.length % 2 == 0) {
    			center = Math.floorDiv(this.length,2);
    		}
    		else {
    			center = 1 + (Math.floorDiv(this.length,2));
    		}
    		int count = 1;
    		
    		while (count <= center) {
    			left.moveFrontToRear(this);
    			count += 1;
    		}
    		
    		while (count > center && this.length != 0) {
    			right.moveFrontToRear(this);
    		}
    	}

	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. Nodes are moved alternately
     * from this SingleList to left and right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

    	boolean valid = true;
    	while (this.length != 0) {
    		if (valid) {
    			left.moveFrontToRear(this);
    		}else {
    			right.moveFrontToRear(this);
    		}
    		valid = !valid;
    	}

	return;
    }

    /**
     * Creates a union of two other SingleLists into this SingleList. Copies value
     * to this list. left and right SingleLists are unchanged. Values from left are
     * copied in order first, then values from right are copied in order.
     *
     * @param left  The first SingleList to create a union from.
     * @param right The second SingleList to create a union from.
     */
    public void union(final SingleList<T> left, final SingleList<T> right) {
    	
    	
    	SingleNode<T> current1 = left.front, current2 = right.front;
    	
    	
    	while (Objects.isNull(current1) == false) {
    		
    		SingleNode<T> contains = this.linearSearch(current1.getData());
    		
    		if (Objects.isNull(contains)) {
    			
    			this.append(current1.getData());
    		}
    		current1 = current1.getNext();
    	}
    	
    	while (Objects.isNull(current2) == false) {
    		
    		SingleNode<T> search2 = this.linearSearch(current2.getData());
    		
    		if (Objects.isNull(search2)) {
    			
    			this.append(current2.getData());
    		}
    		current2 = current2.getNext();
    	}

	return;
    }
}